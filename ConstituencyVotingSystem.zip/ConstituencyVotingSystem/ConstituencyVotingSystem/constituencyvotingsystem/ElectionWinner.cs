﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConstituencyVotingSystem
{
    public partial class ElectionWinner : Form
    {
        public ElectionWinner()
        {
            InitializeComponent();
        }
    }
}
